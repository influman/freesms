# Installation
Gestion des Notifications SMS via API Free Mobile
    
  
### Ajout du p�riph�rique
Cliquez sur "Configuration" / "Ajouter ou supprimer un p�riph�rique" / "Store eedomus" / "Notifications SMS FreeMobile" / "Cr�er"  

  
*Voici les diff�rents champs � renseigner:*

* [Obligatoire] - Le login de votre compte FreeMobile  
* [Obligatoire] - La cl� API SMS FreeMobile associ� � votre num�ro de t�l�phone (voir vos options de compte)  

  
### Utilisation
Pr�d�finissez des notifications dans les valeurs du p�riph�rique cr�� par le plugin.  
Respectez bien la forme des valeurs et l'url du script appel�, � l'instar des valeurs par d�faut fournies � la cr�ation.  
*NB1 : Ne supprimez pas la valeur cach�e 9999 - [CHATBOT], d�di�e au plugin du m�me nom.*  
*NB2 : Ne supprimez pas la valeur cach�e 99999 - [ASK], d�di�e au plugin du m�me nom.*  
  
Vous pouvez int�grer la valeur d'un ou plusieurs p�riph�riques existants via son code API entre crochet, exemple : [123456].  
Vous pouvez sauter une ligne dans le message en utilisant [BR].  
Ins�rer la date [DATE] ou l'heure [TIME].  
  
Lancez ensuite vos notifications depuis vos r�gles.  

